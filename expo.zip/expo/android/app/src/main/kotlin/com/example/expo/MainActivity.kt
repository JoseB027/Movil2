package com.example.expo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
